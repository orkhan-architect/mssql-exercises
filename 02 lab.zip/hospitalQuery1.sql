--CREATE DATABASE Hospital;
USE Hospital;

--CREATE TABLE Departments(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
--	[Name] NVARCHAR(100) NOT NULL CHECK([Name]!='') UNIQUE
--);

--CREATE TABLE Doctors(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
--	[Name] NVARCHAR(MAX) NOT NULL CHECK([Name]!=''),
--	[Premium] MONEY NOT NULL CHECK([Premium]>=0) DEFAULT 0,
--	[Salary] MONEY NOT NULL CHECK([Salary]>0),
--	[Surname] NVARCHAR(MAX) NOT NULL CHECK([Surname]!=''),
--	[Workdays] NVARCHAR(30) NOT NULL CHECK([Workdays]!='')
--);

--CREATE TABLE Specializations(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
--	[Name] NVARCHAR(100) NOT NULL CHECK([Name]!='') UNIQUE
--);

--CREATE TABLE DoctorsSpecializations(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
--	[DoctorId] INT NOT NULL FOREIGN KEY REFERENCES [Doctors](Id),
--	[SpecializationId] INT NOT NULL FOREIGN KEY REFERENCES [Specializations](Id),
--	[DepartmentId] INT NOT NULL FOREIGN KEY REFERENCES [Departments](Id)
--);

--CREATE TABLE Sponsors(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
--	[Name] NVARCHAR(100) NOT NULL CHECK([Name]!='') UNIQUE
--);

--CREATE TABLE Diseases(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
--	[Name] NVARCHAR(50) NOT NULL CHECK([Name]!='') UNIQUE,
--	[Type] NVARCHAR(20) NOT NULL CHECK([Type]!=''),
--	[WarningLevel] INT NOT NULL CHECK([WarningLevel]>0 AND [WarningLevel]<6)
--);

--CREATE TABLE Donations(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
--	[Amount] MONEY NOT NULL CHECK([Amount]>0),
--	[Date] DATE NOT NULL CHECK([Date]<=GETDATE()) DEFAULT GETDATE(),
--	[DepartmentId] INT NOT NULL FOREIGN KEY REFERENCES [Departments](Id),
--	[SponsorId] INT NOT NULL FOREIGN KEY REFERENCES [Sponsors](Id)
--);

--CREATE TABLE Wards(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
--	[Name] NVARCHAR(20) NOT NULL CHECK([Name]!='') UNIQUE,
--	[DepartmentId] INT NOT NULL FOREIGN KEY REFERENCES [Departments](Id),
--	[DiseaseId] INT NOT NULL FOREIGN KEY REFERENCES [Diseases](Id)
--);

--CREATE TABLE Vacations(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
--	[EndDate] DATE NOT NULL,
--	[StartDate] DATE NOT NULL,
--	[DoctorId] INT NOT NULL FOREIGN KEY REFERENCES [Doctors](Id),
--	CHECK([EndDate]>[StartDate])
--);

--INSERT INTO Departments([Name]) VALUES('Intensive Treatment');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Adamo', '$2998.15', '$16036.22', 'Heisman', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Norri', '$2644.00', '$20591.46', 'Haggarty', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Dusty', '$2944.01', '$5012.56', 'Astle', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Vivian', '$2011.74', '$16200.52', 'Jaszczak', 'restdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Eimile', '$2392.43', '$18338.42', 'Linfield', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Rodina', '$1213.16', '$10425.33', 'Veeler', 'restdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Greta', '$2497.18', '$5910.63', 'Kamen', 'allweek');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Ardene', '$1891.39', '$19510.70', 'Lindores', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Ami', '$367.66', '$14008.34', 'O''Feeny', 'allweek');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Erwin', '$1851.17', '$5575.87', 'Cowcha', 'weekdays');
--INSERT INTO Specializations([Name]) VALUES('Therapist');
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(1, 1, 1);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(2, 1, 1);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(3, 1, 1);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(4, 1, 1);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(5, 1, 1);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(6, 1, 1);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(7, 1, 1);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(8, 1, 1);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(9, 1, 1);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(10, 1, 1);
--INSERT INTO Vacations(EndDate, StartDate, DoctorId) VALUES('2022-01-15', '2022-01-01', 2);
--INSERT INTO Vacations(EndDate, StartDate, DoctorId) VALUES('2022-02-25', '2022-02-15', 4);
--INSERT INTO Vacations(EndDate, StartDate, DoctorId) VALUES('2022-03-22', '2022-03-05', 6);
--INSERT INTO Vacations(EndDate, StartDate, DoctorId) VALUES('2022-04-10', '2022-04-01', 8);

--INSERT INTO Departments([Name]) VALUES('Laboratory');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Jenda', '$1406.31', '$6049.19', 'Bryett', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Susette', '$2692.93', '$12254.16', 'Udey', 'allweek');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Venita', '$0.00', '$6578.47', 'Bennike', 'allweek');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Moise', '$1046.36', '$18945.58', 'Reburn', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Felipe', '$0.00', '$21453.67', 'Flukes', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Bucky', '$1184.60', '$17212.73', 'Very', 'restdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Helen', '$2192.20', '$15753.61', 'Williams', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Elset', '$1408.09', '$21911.76', 'Scafe', 'restdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Correy', '$2502.32', '$11814.74', 'Lere', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Astra', '$2679.98', '$18124.30', 'OIlier', 'allweek');
--INSERT INTO Specializations([Name]) VALUES('Laborator');
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(11, 2, 2);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(12, 2, 2);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(13, 2, 2);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(14, 2, 2);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(15, 2, 2);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(16, 2, 2);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(17, 2, 2);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(18, 2, 2);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(19, 2, 2);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(20, 2, 2);
--INSERT INTO Vacations(EndDate, StartDate, DoctorId) VALUES('2022-01-25', '2022-01-11', 11);
--INSERT INTO Vacations(EndDate, StartDate, DoctorId) VALUES('2022-02-21', '2022-02-11', 13);
--INSERT INTO Vacations(EndDate, StartDate, DoctorId) VALUES('2022-03-20', '2022-03-02', 15);
--INSERT INTO Vacations(EndDate, StartDate, DoctorId) VALUES('2022-04-09', '2022-04-02', 17);

--INSERT INTO Departments([Name]) VALUES('Infectious Diseases');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Nollie', '$449.63', '$22599.53', 'Mosen', 'restdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Adele', '$412.43', '$23949.76', 'Begent', 'allweek');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Shari', '$1193.37', '$15994.84', 'Iffe', 'allweek');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Mercy', '$1317.18', '$28670.65', 'Lubomirski', 'allweek');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Nikolas', '$2006.79', '$15298.39', 'Caudell', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Jon', '$0.00', '$24684.90', 'Roakes', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Patrizius', '$1588.56', '$7644.15', 'Marielle', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Ignaz', '$974.04', '$19974.42', 'Habbijam', 'weekdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Fanya', '$2871.30', '$11848.74', 'Eastam', 'restdays');
--INSERT INTO Doctors ([Name], [Premium], [Salary], [Surname], [Workdays]) VALUES ('Rodd', '$1191.56', '$22474.67', 'Kimmel', 'weekdays');
--INSERT INTO Specializations([Name]) VALUES('Professors');
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(21, 3, 3);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(22, 3, 3);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(23, 3, 3);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(24, 3, 3);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(25, 3, 3);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(26, 3, 3);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(27, 3, 3);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(28, 3, 3);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(29, 3, 3);
--INSERT INTO DoctorsSpecializations(DoctorId, SpecializationId, DepartmentId) VALUES(30, 3, 3);
--INSERT INTO Vacations(EndDate, StartDate, DoctorId) VALUES('2022-04-30', '2022-04-15', 29);
--INSERT INTO Vacations(EndDate, StartDate, DoctorId) VALUES('2022-05-05', '2022-05-01', 30);

--INSERT INTO Sponsors([Name]) VALUES('Umbrella Corporation');

--INSERT INTO Diseases([Name], [Type], [WarningLevel]) VALUES('AIDS', 'Virus', 1);
--INSERT INTO Diseases([Name], [Type], [WarningLevel]) VALUES('Corona', 'Virus', 1);
--INSERT INTO Diseases([Name], [Type], [WarningLevel]) VALUES('Ebola', 'Virus', 1);
--INSERT INTO Diseases([Name], [Type], [WarningLevel]) VALUES('Cholera', 'Bacterial', 2);
--INSERT INTO Diseases([Name], [Type], [WarningLevel]) VALUES('Pneumonia', 'Bacterial', 2);
--INSERT INTO Diseases([Name], [Type], [WarningLevel]) VALUES('Tuberculosis', 'Bacterial', 2);
--INSERT INTO Diseases([Name], [Type], [WarningLevel]) VALUES('Allergy', 'Seasonal', 4);
--INSERT INTO Diseases([Name], [Type], [WarningLevel]) VALUES('Body blotch', 'Seasonal', 4);
--INSERT INTO Diseases([Name], [Type], [WarningLevel]) VALUES('Intestinal obstruction', 'Seasonal', 5);

--INSERT INTO Wards([Name], [DepartmentId], [DiseaseId]) VALUES('IT101', 1, 8);
--INSERT INTO Wards([Name], [DepartmentId], [DiseaseId]) VALUES('IT103', 1, 7);
--INSERT INTO Wards([Name], [DepartmentId], [DiseaseId]) VALUES('IT105', 1, 9);
--INSERT INTO Wards([Name], [DepartmentId], [DiseaseId]) VALUES('LAB101', 2, 2);
--INSERT INTO Wards([Name], [DepartmentId], [DiseaseId]) VALUES('LAB103', 2, 1);
--INSERT INTO Wards([Name], [DepartmentId], [DiseaseId]) VALUES('LAB105', 2, 3);
--INSERT INTO Wards([Name], [DepartmentId], [DiseaseId]) VALUES('INF101', 3, 6);
--INSERT INTO Wards([Name], [DepartmentId], [DiseaseId]) VALUES('INF103', 3, 5);
--INSERT INTO Wards([Name], [DepartmentId], [DiseaseId]) VALUES('INF105', 3, 4);

--INSERT INTO Donations([Amount], [Date], [DepartmentId], [SponsorId]) VALUES('$50000.00', '2022-01-05', 1, 1);
--INSERT INTO Donations([Amount], [Date], [DepartmentId], [SponsorId]) VALUES('$500000.00', '2022-03-10', 2, 1);
--INSERT INTO Donations([Amount], [Date], [DepartmentId], [SponsorId]) VALUES('$150000.00', '2022-05-02', 3, 1);
--INSERT INTO Donations([Amount], [Date], [DepartmentId], [SponsorId]) VALUES('$170000.00', '2021-03-12', 2, 1);

--SELECT (Doctors.Name + ' ' + Doctors.Surname) AS [FullName], Specializations.Name AS Specialization FROM Doctors
--INNER JOIN DoctorsSpecializations ON Doctors.Id=DoctorsSpecializations.DoctorId
--INNER JOIN Specializations ON DoctorsSpecializations.SpecializationId=Specializations.Id

--SELECT Doctors.Surname, Doctors.Premium, Doctors.Salary FROM Doctors
--LEFT JOIN Vacations ON Doctors.Id=Vacations.DoctorId
--WHERE (Vacations.Id IS NULL)

--SELECT Wards.Name AS WardName, Departments.Name FROM Wards
--INNER JOIN Departments ON Wards.DepartmentId=Departments.Id
--Where Departments.Name='Intensive Treatment'

--SELECT DISTINCT Departments.Name AS DepName, Sponsors.Name AS Sponsor FROM Departments
--INNER JOIN Donations ON Donations.DepartmentId=Departments.Id
--INNER JOIN Sponsors ON Sponsors.Id=Donations.SponsorId
--WHERE Sponsors.Name='Umbrella Corporation'

--SELECT Departments.Name AS DepName, Sponsors.Name AS Sponsor, Donations.Amount, Donations.Date FROM Departments
--INNER JOIN Donations ON Donations.DepartmentId=Departments.Id
--INNER JOIN Sponsors ON Sponsors.Id=Donations.SponsorId
--WHERE MONTH(GETDATE())=MONTH(Donations.Date)

--SELECT Doctors.Surname, Departments.Name AS DepName FROM Doctors
--INNER JOIN DoctorsSpecializations ON Doctors.Id=DoctorsSpecializations.DoctorId
--INNER JOIN Departments ON Departments.Id=DoctorsSpecializations.DepartmentId
--WHERE (Departments.Id=2 AND Doctors.Workdays='weekdays')

--SELECT Wards.Name AS WardName, Departments.Name AS DepName, (Doctors.Name + ' ' + Doctors.Surname) AS FullName FROM Wards
--INNER JOIN Departments ON Departments.Id=Wards.DepartmentId
--INNER JOIN DoctorsSpecializations ON DoctorsSpecializations.DepartmentId=Departments.Id
--INNER JOIN Doctors ON Doctors.Id=DoctorsSpecializations.DoctorId
--WHERE (Doctors.Name='Helen' AND Doctors.Surname='Williams')

--SELECT Departments.Name AS DepName, (Doctors.Name + ' ' + Doctors.Surname) AS FullName, Donations.Amount AS DepDonation FROM Departments
--INNER JOIN Donations ON Donations.DepartmentId=Departments.Id
--INNER JOIN DoctorsSpecializations ON DoctorsSpecializations.DepartmentId=Departments.Id
--INNER JOIN Doctors ON Doctors.Id=DoctorsSpecializations.DoctorId
--WHERE Donations.Amount>100000
--ORDER BY Donations.Amount

--SELECT Departments.Name AS DepName, (Doctors.Name + ' ' + Doctors.Surname) AS FullName FROM Departments
--INNER JOIN DoctorsSpecializations ON DoctorsSpecializations.DepartmentId=Departments.Id
--INNER JOIN Doctors ON Doctors.Id=DoctorsSpecializations.DoctorId
--WHERE Doctors.Premium=0.00

--SELECT DISTINCT Specializations.Name AS SpecName, Diseases.Name AS Disesase, Diseases.WarningLevel FROM Specializations
--INNER JOIN DoctorsSpecializations ON DoctorsSpecializations.SpecializationId=Specializations.Id
--INNER JOIN Departments ON DoctorsSpecializations.DepartmentId=Departments.Id
--INNER JOIN Wards ON Wards.DepartmentId=Departments.Id
--INNER JOIN Diseases ON Diseases.Id=Wards.DiseaseId
--WHERE Diseases.WarningLevel>3

--SELECT Departments.Name AS DepName, Diseases.Name AS Disesase, Donations.Date FROM Departments
--INNER JOIN Donations ON Donations.DepartmentId=Departments.Id
--INNER JOIN Wards ON Wards.DepartmentId=Departments.Id
--INNER JOIN Diseases ON Diseases.Id=Wards.DiseaseId
--WHERE Donations.Date>DATEADD(m, -6, GETDATE() - DATEPART(d, GETDATE()) + 1)

--SELECT Departments.Name AS DepName, Diseases.Name AS Disesase, Wards.Name AS Ward FROM Departments
--INNER JOIN Wards ON Wards.DepartmentId=Departments.Id
--INNER JOIN Diseases ON Diseases.Id=Wards.DiseaseId
--WHERE Diseases.Type='Virus'