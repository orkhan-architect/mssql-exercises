--CREATE PROCEDURE TextExec
--AS
--print 'Hello, world!'
--GO
--EXEC TextExec;

--CREATE PROCEDURE CurrTime
--AS
--print CAST(GETDATE() AS TIME)
--GO
--EXEC CurrTime;

--CREATE PROCEDURE CurrDate
--AS
--print CAST(GETDATE() AS DATE)
--GO
--EXEC CurrDate;

--CREATE PROCEDURE ThreeSomeSUM
--@a INT, @b INT, @c INT
--AS
--DECLARE @res INT
--SET @res = @a + @b + @c
--RETURN @res

--DECLARE @sum INT
--EXEC @sum = ThreeSomeSUM @a=5, @b=15, @c=20
--SELECT '5+15+20=' AS Query, @sum AS QuerySum

--CREATE PROCEDURE ThreeSomeAVG
--@a INT, @b INT, @c INT
--AS
--DECLARE @res INT
--SET @res = (@a + @b + @c)/3
--RETURN @res

--DECLARE @avg INT
--EXEC @avg = ThreeSomeAVG @a=5, @b=15, @c=25
--SELECT '5+15+25=' AS Query, @avg AS QueryAVG

--CREATE PROCEDURE ThreeSomeMAX
--@a INT, @b INT, @c INT
--AS
--DECLARE @res INT
--	IF @a > @b AND @a > @c SET @res=@a
--	IF @b > @a AND @b > @c SET @res=@b
--	IF @c > @a AND @c > @b SET @res=@c
--RETURN @res

--DECLARE @max INT
--EXEC @max = ThreeSomeMAX @a=45, @b=55, @c=65
--SELECT 'MAX of (45,55,65)' AS Query, @max AS QueryMAX

--CREATE PROCEDURE ThreeSomeMIN
--@a INT, @b INT, @c INT
--AS
--DECLARE @res INT
--	IF @a < @b AND @a < @c SET @res=@a
--	IF @b < @a AND @b < @c SET @res=@b
--	IF @c < @a AND @c < @b SET @res=@c
--RETURN @res

--DECLARE @min INT
--EXEC @min = ThreeSomeMIN @a=45, @b=35, @c=15
--SELECT 'MIN of (45,35,65)' AS Query, @min AS QueryMIN

--CREATE PROCEDURE SymboLine
--@a INT, @b NVARCHAR(1)
--AS 
--DECLARE @Counter INT, @c NVARCHAR(100)
--SET @Counter=1 
--SET @c=''
--WHILE (@Counter <= @a)
--BEGIN 
--	SET @c = @c + @b
--	SET @Counter  = @Counter  + 1
--END
--print @c
--GO
--EXEC SymboLine 5, '#';

--CREATE PROCEDURE Factorial
--@a INT
--AS 
--DECLARE @Fact INT
--SET @Fact=1
--WHILE (@a > 1)
--BEGIN 
--	SET @Fact = @Fact * @a
--	SET @a  = @a  - 1
--END
--RETURN @Fact

--DECLARE @myFactorial INT
--EXEC @myFactorial = Factorial 5
--SELECT 'Factorial of 5' AS Query, @myFactorial AS QueryFactorial

--CREATE PROCEDURE Exponentiation
--@a INT, @b INT
--AS 
--DECLARE @res INT
--SET @res=1
--IF @b > 0
--WHILE @b > 0
--BEGIN
--	SET @res=@res*@a
--	SET @b=@b-1
--END
--IF @b < 0
--WHILE @b < 0
--BEGIN
--	SET @res=@res/@a
--	SET @b=@b+1
--END
--RETURN @res

--DECLARE @myExpon INT
--EXEC @myExpon = Exponentiation @a=2, @b=4
--SELECT '2 ** 4 =' AS Query, @myExpon AS QueryExpon

--DROP PROCEDURE Exponentiation;